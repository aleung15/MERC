%PLOT AUC plots from excel sheet copy pasted into variable temp_data
%fig4_AUC
newcolors = {'#0072BD','#D95319','#EDB120','#7E2F8E','#77AC30','#4DBEEE'};
colororder(newcolors)
%newcolors = {'#0072BD','#D95319','#EDB120'};
%colororder('parula')




bar(1,temp_data(:,1));
set(gca,'xticklabel',{''});
plotformat
figure(2)
bar(1,temp_data(:,2));
set(gca,'xticklabel',{''});
plotformat