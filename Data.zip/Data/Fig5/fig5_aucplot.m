%PLOT AUC plots from excel sheet copy pasted into variable temp_data
%fig4_AUC
newcolors = {'#0072BD','#D95319','#EDB120','#7E2F8E','#77AC30','#4DBEEE'};
%colororder(newcolors)
%newcolors = {'#0072BD','#D95319','#EDB120'};
colororder(newcolors)




bar(1,temp_data(:,1));
hold on
bar(2,temp_data(:,2));
bar(3,temp_data(:,3));
set(gca,'xticklabel',{''});
plotformat
figure(2)
colororder(newcolors)
bar(1,temp_data(:,4));
hold on
bar(2,temp_data(:,5));
bar(3,temp_data(:,6));
set(gca,'xticklabel',{''});
plotformat