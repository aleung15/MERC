%PLOT AUC plots from excel sheet copy pasted into variable temp_data
%fig2_AUC

newcolors = {'#0072BD','#D95319','#EDB120'};
colororder(newcolors)
% atp 
bar(1,[temp_data(1,1),temp_data(3,1),temp_data(5,1)]);
hold on
bar(2,[temp_data(2,1),temp_data(4,1),temp_data(6,1)]);
set(gca,'xticklabel',{''});
plotformat
% atp m
figure (2)
colororder(newcolors)
bar(1,[temp_data(1,2),temp_data(3,2),temp_data(5,2)]);
hold on
bar(2,[temp_data(2,2),temp_data(4,2),temp_data(6,2)]);
set(gca,'xticklabel',{''});
plotformat

