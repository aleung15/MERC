clear
[act_file,act_path]=uigetfile('*.txt');
rawdata = readmatrix([act_path,act_file]);
[~,rd_num] = size(rawdata);
%rd_num = rd_num-1;
modeltime = rawdata(:,rd_num-1);
dat = rawdata(:,rd_num);

startpoints = find(~modeltime);
sec10mark = find(~(modeltime-10));
sec30mark = find(~(modeltime-30));
sec60mark = find(~(modeltime-60));
num_datas = size(startpoints,1);
datalength = length(modeltime)/num_datas;


mitosize= rawdata(:,1);
saratio = rawdata(:,2);
convfactor = 5.1e-19/1e6*6.022e23; %uM/s to molec/s
for i=1:num_datas
    
    
    current_data_10= dat(startpoints(i):sec10mark(i));
    current_time_10 = modeltime(startpoints(i):sec10mark(i));
    auc_10 = trapz(current_time_10,current_data_10);
    current_data_30= dat(startpoints(i):sec30mark(i));
    current_time_30 = modeltime(startpoints(i):sec30mark(i));
    auc_30 = trapz(current_time_30,current_data_30);
    current_data_60= dat(startpoints(i):sec60mark(i));
    current_time_60 = modeltime(startpoints(i):sec60mark(i));
    auc_60 = trapz(current_time_60,current_data_60);
    
    avgrate = mean(current_data_60);
    vals(i) = avgrate;
    auc_10_vec(i) = auc_10;
    auc_30_vec(i) = auc_30;
    auc_60_vec(i) = auc_60;
    mitovec(i)= mitosize(startpoints(i));
    savec(i) = saratio(startpoints(i)); 
    %dset(:,i)= current_data;
end


metrics = [auc_10_vec;auc_30_vec;auc_60_vec];
mat10=reshape(auc_10_vec,6,5);
mat30=reshape(auc_30_vec,6,5);
mat60=reshape(auc_60_vec,6,5);
%delamat=reshape(min_rate_vec,6,5);
