
%newcolors = {'#7E2F8E','#77AC30','#4DBEEE'};
%colororder(newcolors)
[act_file,act_path]=uigetfile('*.txt');
rawdata = readmatrix([act_path,act_file]);

[~,datacols]=size(rawdata);
%datacols=datacols-1;
modeltime = rawdata(:,datacols-1);
%dat = rawdata(:,datacols).*cf_mm_mito(3);
%dat = rawdata(:,datacols).*cf_mm_cyto;
dat = rawdata(:,datacols).*1000;
startpoints = find(~modeltime);
num_datas = size(startpoints,1);
datalength = length(modeltime)/num_datas;
figure(1)
hold on
dset= zeros(datalength,num_datas);
time_set = modeltime(1:datalength);


for i=1:num_datas
    if i<num_datas
        current_data= dat(startpoints(i):startpoints(i+1)-1);
        plot(modeltime(startpoints(i):(startpoints(i+1)-1)),current_data)
    else
     current_data= dat(startpoints(i):end);   
     plot(modeltime(startpoints(i):end),current_data)    
    end
    dset(:,i)= current_data;
end
xlim([0,60])

plotformat
xticklabels('auto')
%legend('mGluR only','NMDAonly','Full Model')