for (i= 1:4)
caxis_bounds=[0,6];
figure(i)
[act_file,act_path]=uigetfile('*.txt');
rawdata = readmatrix([act_path,act_file]);
scatter(10^9*rawdata(:,1),10^9*rawdata(:,2),[],rawdata(:,3),'filled')
h=colorbar;
set(get(h,'title'),'string','\muM');
ylim([-500,1500])
caxis(caxis_bounds)
set(gca,'XTick',[], 'YTick', [])
plotformat
end

