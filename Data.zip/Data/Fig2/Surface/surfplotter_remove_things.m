


figure(1)
caxis([0,5])
set(gca,'XTick',[], 'YTick', [])
figure(2)
caxis([0,5])
set(gca,'XTick',[], 'YTick', [])
figure(3)
caxis([0,5])
set(gca,'XTick',[], 'YTick', [])
figure(4)
caxis([0,5])
set(gca,'XTick',[], 'YTick', [])