
%newcolors = {'#7E2F8E','#77AC30','#4DBEEE'};
%colororder(newcolors)
[act_file,act_path]=uigetfile('*.txt');
rawdata = readmatrix([act_path,act_file]);
[~,datacols]=size(rawdata);
%datacols=datacols-1;
modeltime = rawdata(:,datacols-1);
%dat = rawdata(:,datacols).*cf_mm_mito(3);
%dat = rawdata(:,datacols).*cf_mm_cyto;
dat = rawdata(:,datacols);
startpoints = find(~modeltime);
num_datas = size(startpoints,1);
datalength = length(modeltime)/num_datas;

for i=1:num_datas
    if i<num_datas
      current_data= dat(startpoints(i):startpoints(i+1)-1)  
    elseif num_datas==datalength
     current_data= dat(startpoints(i):end);     
    end
    dset(:,i)= current_data;
end


figure(1)
hold on
time_set = modeltime(1:datalength);
plot(time_set,dset(:,1))
plot(time_set,dset(:,2))
plot(time_set,dset(:,3))
plotformat
xlim([0,20])
xticklabels('auto')
legend('Head','Neck','Shaft')

figure(2)
plot(time_set,dset(:,4))
hold on
plot(time_set,dset(:,5))
plot(time_set,dset(:,6))
plotformat
xlim([0,20])
xticklabels('auto')

figure(3)
plot(time_set,dset(:,7))
hold on
plot(time_set,dset(:,8))
plot(time_set,dset(:,9))
plotformat
xlim([0,20])
xticklabels('auto')