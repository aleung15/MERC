%new version 2021
%comsol_read_structure

[act_file,act_path]=uigetfile('*.txt');
rawdata = readmatrix([act_path,act_file]);

mitolength = rawdata(:,1);
par = rawdata(:,2);
modeltime = rawdata(:,3);
dat = rawdata(:,4);





startpoints = find(~modeltime);
num_datas = size(startpoints,1);
datalength = diff(startpoints(1:2));
dset= zeros(datalength,num_datas);
time_set = modeltime(1:datalength);
modeltime_mat = zeros(datalength,num_datas);


for i=1:num_datas
    if i<num_datas
        current_data= dat(startpoints(i):startpoints(i+1)-1);
        current_time = modeltime(startpoints(i):startpoints(i+1)-1);
        current_mitolength = mitolength(startpoints(i));
        current_khyd = par(startpoints(i));
    else
        current_data= dat(startpoints(i):end);   
        current_time = modeltime(startpoints(i):end);
        current_mitolength = mitolength(startpoints(i));
        current_khyd = par(startpoints(i));
    end
    dset(:,i)= current_data;
    modeltime_mat(:,i) = current_time;
    aucvec(i) = trapz(current_time,current_data);
    khydvec(i) = current_khyd;
    mitovec(i) = current_mitolength;

end
results = [aucvec;khydvec;mitovec]';

