function [] = fig6_aucplot(workingstruct)
timemat=workingstruct.time;
catpmat = workingstruct.auc_catp;
matpmat =workingstruct.auc_matp;

row = 4;
col =5 ;

for i = 1:row
for j = 1:col
catpaucmat(i,j) = trapz(cell2mat( timemat(i,j)),cell2mat( catpmat(i,j)));
matpaucmat(i,j) = trapz(cell2mat( timemat(i,j)),cell2mat( matpmat(i,j)));
end
end

figure(1)
row_tick = [0,0.025,0.05,0.1,0.2];
col_tick = [0.3,0.6,0.8,1.2];
pcolor(row_tick,col_tick,catpaucmat)
shading interp
xlabel('MERC SA Ratio')
ylabel('Mitochondrial Length [\mum]')
caxis([0.5e-17,5e-17])
colormap(jet)
colorbar
plotformat
set(gcf, 'Position',  [200, 200, 450, 370])

figure(2)
pcolor(row_tick,col_tick,matpaucmat);
shading interp
xlabel('MERC SA Ratio')
ylabel('Mitochondrial Length [\mum]')
caxis([0.5e-17,10e-17])
colormap(jet)
colorbar
plotformat
set(gcf, 'Position',  [200, 200, 450, 370])

end