
figure(1)
row_tick = [0.01,0.05,0.1,0.15,0.2];
col_tick = [0.2,0.4,0.6,0.8,1.0,1.2];
pcolor(row_tick,col_tick,struct_test)
shading interp
caxis([2e9,2e10])
colormap(jet)
colorbar
plotformat
set(gcf, 'Position',  [200, 200, 450, 370])
